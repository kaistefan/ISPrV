package verteilung;
import java.util.List;

import daten.*;

public class Step {
	Student studt;
	List<Student> list;
	
	public Step (Student studt,List<Student> list){
		this.studt=studt;
		this.list=list;
	}
}
