package verteilung;

public class SolutionException extends Exception
{
	SolutionException()
    {
        super("Keine m�gliche l�sung!!!");
    }
}
