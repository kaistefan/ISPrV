package daten;

import optimierung.Optimierung;
import verteilung.*;


public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Praktikas pr=new Praktikas();
		pr.generat(0,10,20);
		System.out.println(pr.einF.get(0).studId);
		Praktikas pr2 =pr.clone();
		System.out.println("l�nge liste 1 "+pr.einF.size());

		System.out.println("l�nge liste 2 "+pr.zweiF.size());

		System.out.println("l�nge liste 3 "+pr.dreiF.size());
	
		Verteilung ver=new Verteilung();
		
			ver.teileEin(pr);
		
		System.out.println("l�nge liste 1 "+pr2.einF.size());

		System.out.println("l�nge liste 2 "+pr2.zweiF.size());

		System.out.println("l�nge liste 3 "+pr2.dreiF.size());
		
			ver.teileEin(pr2);
		
		System.out.println("l�nge liste 1 "+pr.einF.size());

		System.out.println("l�nge liste 2 "+pr.zweiF.size());

		System.out.println("l�nge liste 3 "+pr.dreiF.size());

		System.out.println("Happyall pr1 "+pr.getHappyAll());
		System.out.println("Happyall pr2 "+pr2.getHappyAll());
		
		Optimierung op=new Optimierung();
		final long timeStart = System.currentTimeMillis(); 
		op.optimum(pr);
		 final long timeEnd = System.currentTimeMillis();
	     System.out.println("Verlaufszeit der ersten Optimierung: " + (timeEnd - timeStart) + " Millisek."); 
	     final long timeStart2 = System.currentTimeMillis();
		op.optimum(pr2);
		 final long timeEnd2 = System.currentTimeMillis();
	     System.out.println("Verlaufszeit der zweiten Optimierung: " + (timeEnd2 - timeStart2) + " Millisek."); 
		System.out.println("Happyall pr1 op "+pr.getHappyAll());
		System.out.println("Happyall pr2 op "+pr2.getHappyAll());
		} catch (SolutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
